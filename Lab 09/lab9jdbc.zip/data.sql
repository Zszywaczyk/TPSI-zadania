-- inicjalizacja bazy danych: przykładowe dane

insert into blog_post(title, content) values ('Pierwszy wpis', 'Oto pierwszy nasz wpis na blogu, krótki raczej');
insert into blog_post(title, content) values ('Prognoza pogody', 'Jutro biomet raczej niekorzystny, najwyraźniej zbiera się na laborki. W godzinach popołudniowych możliwy wykład');
insert into blog_post(title, content) values ('Lorem ipsum', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. 
Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna. 
Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. 
Proin pharetra nonummy pede. Mauris et orci. Aenean nec lorem. In porttitor. Donec laoreet nonummy augue. Suspendisse dui purus, scelerisque at, 
vulputate vitae, pretium mattis, nunc. Mauris eget neque at sem venenatis eleifend. Ut nonummy.');
